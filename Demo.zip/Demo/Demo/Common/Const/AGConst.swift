import Foundation

typealias AG_BLANK_BLOCK = () -> Void
typealias AG_FailedSTRNG_BLOCK = (String) -> Void
typealias AG_Dictionary_BLOCK = ([String:Any]) -> Void

typealias AG_String_BLOCK = (String) -> Void
typealias AG_Int_BLOCK = (Int) -> Void
typealias AG_BOOL_BLOCK = (Bool) -> Void
typealias AG_Double_BLOCK = (Double) -> Void
