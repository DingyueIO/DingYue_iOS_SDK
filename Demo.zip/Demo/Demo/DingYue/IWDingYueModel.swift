//
//  IWDingYueModel.swift
//  AMDT
//
//  Created by TJ on 2024/10/17.
//

//import KakaJSON
//
//struct IWDingYueSwitch:Convertible {
//
//    var limit_offer:Bool = false
//}
//
//struct IWDingYueConfiguration:Convertible {
//    var localeValues:[String:String]?
//    var `default`:String = ""
//    var key:String = ""
//}
//
//struct IWDingYuePageConfig:Convertible {
//    var name:String = ""
//    var version:String = ""
//    var delay_close:Int = 0
//}
//
//struct IWDingYueConfiguration_limitedOffer:Convertible {
//    var default_expires:Int = 3600
//    var expires:Int = 3600
//}
//
//struct IWDingYueConfiguration_scan:Convertible {
//    var free_scanTimes:Int = 3
//    var free_time:Int = 3600
//}
