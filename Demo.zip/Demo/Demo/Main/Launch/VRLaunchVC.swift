//
//  LaunchVC.swift
//  FindDevice
//
//  Created by TJ on 2025/1/7.
//

import UIKit

import AppTrackingTransparency
//import APNGKit

class VRLaunchVC: UIViewController {

//    @IBOutlet weak var apngIV: APNGImageView!
    
    var alreadyLoadData = false
    var shouldNavigateToGuidePage = false
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
    }
    
    func setupUI() {
        view.backgroundColor = .white
        
        NotificationCenter.default.addObserver(self, selector: #selector(networkMonitorStatus(noti:)), name: AGNotificationNetworkMonitorStatus, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(appDidBecomeActive), name: UIApplication.didBecomeActiveNotification, object: nil)
        AGNetworkMonitor.shared.startMonitoring()
    }
    
    @objc func appDidBecomeActive() {
        toGuidePage()
    }

    @objc func networkMonitorStatus(noti:Notification) {
        if let status:AGNetworkMonitorStatus = noti.object as? AGNetworkMonitorStatus {
            switch status {
            case .connected:
                requestNotificationPermission()
                loadData()
                break
            default:
                break
            }
        }
    }
    
    func requestNotificationPermission() {
        print("开始请求通知权限 =====")
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) {[weak self] granted, error in
            if granted {
                print("通知权限请求结果：已授权")
                DispatchQueue.main.async {
                    UIApplication.shared.registerForRemoteNotifications()
                    print("注册远程通知")
                }
            } else {
                print("通知权限请求结果：未授权")
                if let error = error {
                    print("通知权限请求错误：\(error.localizedDescription)")
                }
            }
        }
    }
    
    func loadData() {
        guard alreadyLoadData != true else {return}
        alreadyLoadData = true
        
        let group = DispatchGroup()

        group.enter()
        IWDingYueManager.config(success: {
            group.leave()
        }, failed: {
            group.leave()
        })
        
        group.notify(queue: DispatchQueue.main) {[weak self] in
            guard let sself = self else { return }
            debugPrint("Aleardy enter.........")
            if UIApplication.shared.applicationState == .active {
                sself.shouldNavigateToGuidePage = true
                sself.toGuidePage()
            }else{
                sself.shouldNavigateToGuidePage = true
            }
        }
    }

    func toGuidePage() {
        guard shouldNavigateToGuidePage else {return}
        shouldNavigateToGuidePage = false
        IWDingYueManager.showDingYueGuidePage(fromVC: self)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        // 记录页面进入事件
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        // 只在页面真正退出时触发 leave 事件

    }
}
